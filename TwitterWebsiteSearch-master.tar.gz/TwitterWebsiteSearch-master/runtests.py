import tests.test_TweetParser

tests.test_TweetParser.suite()

import tests.test_integration

# tests.test_integration.to_csv('$APPL', 10)

# tests.test_integration.simple_test()
